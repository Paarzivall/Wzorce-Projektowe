from abc import ABC, abstractmethod


class BazaDanych(ABC):
    def WykonajSelect(self, zapytanie):
        pass
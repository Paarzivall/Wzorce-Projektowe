from Komponent import Komponent


class Potwierdzenie(Komponent):
    def drukuj(self):
        print("POTWIERDZENIE")

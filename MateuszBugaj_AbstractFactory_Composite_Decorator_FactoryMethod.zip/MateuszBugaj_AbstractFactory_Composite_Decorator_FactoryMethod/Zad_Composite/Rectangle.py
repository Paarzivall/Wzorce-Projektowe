from Graphic import Graphic


class Rectangle(Graphic):
    def draw(self):
        print("Rysuje prostokat")
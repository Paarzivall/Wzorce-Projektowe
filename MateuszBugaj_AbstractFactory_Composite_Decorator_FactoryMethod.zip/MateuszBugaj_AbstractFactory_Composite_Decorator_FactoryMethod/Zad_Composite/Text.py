from Graphic import Graphic


class Text(Graphic):
    def draw(self):
        print("Rysuje tekst")
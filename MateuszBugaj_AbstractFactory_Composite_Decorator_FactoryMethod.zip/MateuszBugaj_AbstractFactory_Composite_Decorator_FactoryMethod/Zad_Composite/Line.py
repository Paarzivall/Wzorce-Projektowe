from Graphic import Graphic


class Line(Graphic):
    def draw(self):
        print("Rysuje linie")
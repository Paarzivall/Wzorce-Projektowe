class SDWR(object):
    def drukuj(self):
        print("Drukuję za pomocą drukarki wysokiej rozdzielczości")
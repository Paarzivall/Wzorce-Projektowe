class SEWR(object):
    def rysuj(self):
        print("Rysuje figurę za pomocą sterownika ekranu wysokiej rozdzielczości")
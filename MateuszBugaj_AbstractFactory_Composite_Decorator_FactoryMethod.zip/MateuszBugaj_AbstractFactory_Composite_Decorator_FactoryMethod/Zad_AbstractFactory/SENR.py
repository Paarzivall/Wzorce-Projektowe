class SENR(object):
    def rysuj(self):
        print("Rysuje figurę za pomocą sterownika ekranu niskiej rozdzielczości")
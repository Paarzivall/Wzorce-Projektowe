class SDNR(object):
    def drukuj(self):
        print("Drukuję za pomocą drukarki niskiej rozdzielczości")
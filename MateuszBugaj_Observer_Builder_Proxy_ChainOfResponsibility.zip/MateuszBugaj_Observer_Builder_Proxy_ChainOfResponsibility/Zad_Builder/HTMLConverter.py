from abc import ABC


class HTMLConverter(ABC):
    def ConvertCharacter(self, character):
        pass

    def ConvertTag(self, tag):
        pass
from LiczKwadratowe import LiczKwadratowe

if __name__ == '__main__':
    proxy = LiczKwadratowe()

    print("a = 2, b = 3, c = 4, x = 1")
    print(proxy.Licz(2, 3, 4, 1))
    print(proxy.Licz(2, 3, 4, 1))

    print("a = 3, b = 4, c = 5, x = 2")
    print(proxy.Licz(3, 4, 5, 2))
    print(proxy.Licz(3, 4, 5, 2))

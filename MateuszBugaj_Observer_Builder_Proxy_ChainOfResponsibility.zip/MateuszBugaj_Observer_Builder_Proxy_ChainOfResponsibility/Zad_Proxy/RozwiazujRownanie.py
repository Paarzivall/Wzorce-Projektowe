class RozwiazujRownanie(object):
    def Licz(self, a, b, c, x):
        return a * x * x + b * x + c
from abc import ABC


class Observer(ABC):
    def Update(self):
        pass